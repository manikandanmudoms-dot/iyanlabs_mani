# iyanLabs Digital Experience

Working React + TypeScript + Vite website, built from the supplied brief and DESIGN.md.

## Scope and delivery
This project was built in the assistant's isolated workspace. No connection to your Google Antigravity workspace was available, and no existing repository was supplied. Your local project and production website have not been changed. Import this folder into Antigravity, or merge its components carefully into an existing repository rather than replacing unrelated files.

## Run
Use Node 24 (the tested runtime), or a version supported by Vite: Node 20.19+ or 22.12+.

```sh
npm install
npm run dev
```

The development server prints its local address. For a strict production build:

```sh
npm run build
npm run preview
```

`npm run build` runs TypeScript typechecking before Vite. `npm run typecheck` runs the strict typecheck separately. No lint configuration was present in the supplied workspace; no lint pass is claimed.

### Preview the included production build without installing npm packages
From this folder, with Python 3 installed:

```sh
python -m http.server 8080 --directory dist
```

Open the local server in your browser. The site needs HTTP serving; do not double-click dist/index.html. The included dist is the default email-draft version, not the test endpoint build.

## Implementation plan and completed work
1. Inspect: inspected the available workspace, read DESIGN.md, reviewed the official home/product/contact destinations. No existing app framework or approved image assets were supplied.
2. Visual system: centralised semantic and component tokens, Space Grotesk/Inter with local fallbacks, shared buttons and labels, sticky responsive header and footer.
3. Website: connected-studio hero; business challenges; asymmetric Salesforce/MuleSoft/mobile service panels; interactive architecture; delivery process; Varavu showcase; about/values; contact form.
4. Motion: CSS/SVG data paths, pointer parallax on suitable desktops, reversible viewport reveals and process-line progress. Reduced motion disables animation. Text remains visible if animation or IntersectionObserver fails.
5. Verification: production Vite build, development server smoke check, browser checks at nine widths, anchors, keyboard architecture, mobile menu, form validation, reduced motion and simulated endpoint responses.

## Design decisions
- DESIGN.md contains both YAML semantic colours and prose component colours. src/tokens.css preserves the exact YAML roles and maps component aliases to the explicit prose values. For example, semantic primary is #5d39e5, while the component brand is #7657FF.
- Orange CTA backgrounds and white text are retained. Primary CTA labels are 19px bold to meet the large-text contrast threshold; this is a deliberate accessibility exception to the document's smaller label token. Orange hover uses a dark text token for contrast.
- Interfaces are clearly labelled illustrative concepts. They are not screenshots of actual client deployments or Varavu screens. Decorative chart bars are illustrative, not financial data or performance claims.
- No client logos, testimonials, invented metrics, official-partner claims or employee portraits are included.
- The monogram is a new text-based UI treatment, not an asserted official logo. No favicon is presented as an approved brand asset.
- Fonts are loaded from Google Fonts; system fallbacks keep the site usable without that connection. Self-host approved font files if required by your deployment/privacy policy.
- The desktop network is simplified to a vertical, labelled flow on mobile. All connection roles are also described in text.

## Contact setup
Without a configured backend, the button says **Prepare email draft**. It opens a mailto draft and explicitly says nothing was sent by the website. An email client must be configured on the visitor's device; the direct email link remains available.

For actual online submission, copy .env.example to .env.local and configure a public HTTPS endpoint:

```env
VITE_CONTACT_ENDPOINT=/api/contact
```

A same-origin relative endpoint is recommended. Cross-origin endpoints need appropriate CORS handling. Rebuild after changing this value; Vite variables are embedded at build time. Never put API keys or mail-service credentials in VITE_ variables.

The endpoint receives POST JSON:

```json
{
  "name": "Visitor name",
  "email": "visitor@example.com",
  "company": "Optional company",
  "service": "MuleSoft Integration",
  "project": "Project description",
  "source": "iyanlabs-website"
}
```

The backend must perform server-side validation, enforce field limits, apply rate limiting/spam protection, manage retention and send or store the enquiry using server-side credentials. Return 2xx only after accepting the enquiry; return a non-2xx status on rejection. The frontend reports acceptance by the service, never guaranteed email delivery. Network failures and rejected requests retain the entered data. A 15-second request timeout prevents indefinite submission state. Duplicate submissions are disabled while a request is pending.

No backend was supplied or deployed. Live message delivery has NOT been tested. Browser tests used intercepted 200/500 responses, not a real service. Review the existing privacy notice for the chosen enquiry-processing arrangement before launch.

## Verified public destinations
- Company site: https://iyanlabs.com/
- Varavu: https://iyanlabs.com/products.html#varavu
- Company email published in the official footer: iyanlabstech@gmail.com
- LinkedIn published in the official footer: https://www.linkedin.com/in/iyan-labs-764abb402/
- Privacy/terms destination linked by the official footer: https://iyanlabs.com/terms-web.html

The privacy page's body could not be retrieved during this session; its destination was verified from the official navigation, not its legal contents. External links should be rechecked before release.

## SEO and deployment
Static HTML includes title, description, canonical URL, Open Graph metadata and verified organisation details. public/og-image.png is a newly created social card and is copied into dist. Its production URL becomes available only after deploying the asset to the configured domain; it is not claimed to be live now. The no-JavaScript fallback includes service positioning and direct contact links. The full interactive page requires JavaScript.

Deploy dist to your static hosting platform after running a successful strict build. The canonical domain is the supplied official domain. If deploying under a subdirectory, configure Vite base and update asset/metadata paths accordingly. Configure HTTPS and appropriate security headers at the hosting layer. No hosting deployment, Lighthouse audit, full WCAG audit or cross-browser certification is claimed.

## Verification status and remaining checks
- Vite 8.0.16 production build: passed using available installed packages.
- React/ReactDOM 19.2.1 and Node 24.16.0: used for build and runtime checks.
- Development server: HTTP 200 smoke check passed.
- TypeScript 5.8.3 syntax/transpilation diagnostics: zero.
- Strict `npm run typecheck`: attempted but could not pass because @types/react and @types/react-dom are unavailable in this environment. Package downloads returned HTTP 403. They are declared in package.json. Run npm install and npm run build in your workspace to complete semantic typechecking. This limitation is not hidden by disabling strict mode or adding fake type declarations.
- Browser tests: passed in installed Chromium; see docs/test-results.json.
- Responsive widths: 320, 375, 390, 639, 640, 768, 1024, 1280 and 1440px, with no horizontal document overflow.
- No JavaScript runtime errors recorded during browser tests.
- Contact endpoint acceptance/rejection: passed with intercepted test responses; no real delivery tested.

## Browser test reproduction
The optional tests/browser_check.py uses Python Playwright. Install it and its Chromium browser in a test environment. The script expects the default production build in dist and a second build with VITE_CONTACT_ENDPOINT=/api/contact in the sibling endpoint-dist directory. Set CHROMIUM_EXECUTABLE_PATH only if using a separately installed Chromium. No test sends a live enquiry.

```sh
npm run build
VITE_CONTACT_ENDPOINT=/api/contact npx vite build --outDir ../endpoint-dist
python tests/browser_check.py
```

The endpoint build is for tests only. Do not deploy it as your default site unless a real endpoint is configured.

## File map
- src/App.tsx: page composition, navigation, viewport and pointer interactions
- src/data.ts: service content and verified public destinations
- src/components/Visuals.tsx: custom interface and architecture components
- src/components/Contact.tsx: validation, honest draft fallback and endpoint integration
- src/tokens.css: DESIGN.md-derived central tokens
- src/styles.css: layout, responsive rules and motion
- public/: social-card assets
- dist/: tested production frontend bundle
- docs/: test evidence and responsive screenshots
- DESIGN.md: unchanged supplied design system
