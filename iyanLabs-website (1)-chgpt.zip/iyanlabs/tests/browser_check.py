from playwright.sync_api import sync_playwright
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
import threading, json, os
root=Path(__file__).resolve().parents[1]
base=root.parent
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
servers=[]
for port,directory in [(4173,root/'dist'),(4174,base/'endpoint-dist')]:
 s=ThreadingHTTPServer(('127.0.0.1',port),partial(Quiet,directory=str(directory)));threading.Thread(target=s.serve_forever,daemon=True).start();servers.append(s)
results={'layouts':[],'checks':[],'runtime_errors':[]}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_EXECUTABLE_PATH'))
 page=browser.new_page(viewport={'width':1440,'height':1000})
 page.on('pageerror',lambda e:results['runtime_errors'].append(str(e)))
 page.goto('http://127.0.0.1:4173',wait_until='networkidle')
 for width in [320,375,390,639,640,768,1024,1280,1440]:
  page.set_viewport_size({'width':width,'height':900});page.wait_for_timeout(150)
  dimensions=page.evaluate('({viewport:innerWidth,document:document.documentElement.scrollWidth})')
  assert dimensions['document']<=width, str(dimensions)
  results['layouts'].append({'width':width,'no_horizontal_overflow':True})
  if width in [390,768,1440]:page.screenshot(path=str(root/'docs'/f'preview-{width}.png'),full_page=True)
 results['checks'].append('Responsive overflow checks passed at all nine widths.')
 broken=page.evaluate("Array.from(document.querySelectorAll('a[href^=\"#\"]')).filter(a=>!document.getElementById(a.getAttribute('href').slice(1))).map(a=>a.getAttribute('href'))")
 assert not broken,broken
 results['checks'].append('Every internal anchor resolves to an existing element.')
 for i in range(4):
  page.locator('.system-node').nth(i).click();assert page.locator('.system-node').nth(i).get_attribute('aria-pressed')=='true'
 page.locator('.system-node').nth(0).focus();page.keyboard.press('Tab');assert page.locator('.system-node').nth(1).get_attribute('aria-pressed')=='true'
 results['checks'].append('Architecture nodes work with pointer and keyboard.')
 page.set_viewport_size({'width':390,'height':844});page.locator('.menu-toggle').click();assert page.locator('.menu-toggle').get_attribute('aria-expanded')=='true';page.keyboard.press('Escape');assert page.locator('.menu-toggle').get_attribute('aria-expanded')=='false'
 assert page.locator('.menu-toggle').evaluate('(el)=>el===document.activeElement')
 page.locator('.menu-toggle').click();page.locator('#main-navigation a[href="#services"]').click();assert page.locator('.menu-toggle').get_attribute('aria-expanded')=='false'
 results['checks'].append('Mobile menu opens, closes on navigation and Escape, and restores focus.')
 page.locator('.contact-form button').click();assert page.locator('.field-error').count()==4
 assert page.locator('#name').evaluate('(el)=>el===document.activeElement')
 page.locator('#name').fill('Test User');page.locator('#email').fill('test@example.com');page.locator('#service').select_option('Multiple Services');page.locator('#project').fill('Connect our CRM and mobile workflow.');page.locator('.contact-form button').click();assert page.locator('.field-error').count()==0
 assert 'Nothing has been sent' in page.locator('.form-status').inner_text()
 results['checks'].append('Required-field validation, first-error focus and honest email-draft state passed.')
 page.emulate_media(reduced_motion='reduce');assert page.locator('.path-live').first.evaluate('(el)=>getComputedStyle(el).animationName')=='none'
 results['checks'].append('Reduced-motion preference disables animations.')
 assert page.locator('h1').count()==1
 assert page.locator('title').inner_text().startswith('iyanLabs')
 results['checks'].append('Single H1 and static title metadata present.')
 endpoint=browser.new_page(viewport={'width':1280,'height':900});endpoint.on('pageerror',lambda e:results['runtime_errors'].append(str(e)))
 def fill():
  endpoint.locator('#name').fill('Test User');endpoint.locator('#email').fill('test@example.com');endpoint.locator('#service').select_option('MuleSoft Integration');endpoint.locator('#project').fill('A test enquiry, not a real submission.')
 for code in [200,500]:
  endpoint.route('**/api/contact',lambda route,request,c=code:route.fulfill(status=c,content_type='application/json',body='{}'))
  endpoint.goto('http://127.0.0.1:4174',wait_until='networkidle');fill();endpoint.locator('.contact-form button').click()
  endpoint.wait_for_function("!document.querySelector('.contact-form button').disabled")
  text=endpoint.locator('.form-status').inner_text()
  assert ('accepted by the configured' in text) if code==200 else ('could not confirm' in text)
  endpoint.unroute('**/api/contact')
 results['checks'].append('Configured endpoint accepted/error states passed using intercepted test responses; no live delivery tested.')
 assert not results['runtime_errors'],results['runtime_errors']
 browser.close()
for s in servers:s.shutdown()
(root/'docs/test-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
